from time import time as tm
import codecs, random, os.path



def cheching_for_start():
    '''
    Проверяет наличие всех нужных файлов
    :return: True or False
    '''
    main_katalog = os.path.isdir('texts_for_reading')
    if main_katalog:
        list_for_check = ['texts_for_reading/texts_light_level.txt',
                          'texts_for_reading/texts_medium_level.txt',
                          'texts_for_reading/texts_hard_level.txt',
                          'texts_for_reading/choice.txt']
        for i in list_for_check:
            check_file = os.path.exists(i)
            if not check_file:
                return False
        return True
    return False


def greeting():
    '''
    Приветствие с пользователем и вопрос о готовности его к чтению
    :return: prepare_to_read(), если пользователь готов
    '''
    print('Команды для ответов:', p_n)
    answer = input('\nЗдравствуйте пользователь! \nВы готовы проверить свою скорость чтения? \n').lower()
    while answer not in p_n:
        answer = input('Я вас не понял... \n').lower()
    if answer in positive:
        prepare_to_read()
    elif answer in negative:
        print('Хорошего времяпровождения!')


def prepare_to_read():
    '''
    Выбор одного из 3-ёх режимов
    :return: choices(list_of_func[int(answer) - 1]), если 1 или 2; None, если 3
    '''
    print('Выберите режим: \n' + "\n".join(list_of_offers))
    answer = input()
    while not answer.isdigit() or not 0 < int(answer) < 4:
        answer = input('Неправильный формат данных! Введите снова: \n').lower()
    if answer == '3':
        print('До свидания!')
        return
    choices(list_of_func[int(answer) - 1])


def choice_of_text():
    '''
    Выбор текста, если в prepare_to_read выбрали 1
    :return: reading(answer - k - 1, item)
    '''
    print('Выбирите номер текста:', '\n')
    file_choice = codecs.open("texts_for_reading/choice.txt", 'r', 'utf_8_sig')
    data_choice = list(map(str.strip, file_choice.readlines()))
    file_choice.close()
    counter = 0
    for i in range(len(data_choice)):
        if data_choice[i][0] == '~':
            print(data_choice[i])
            counter += 1
        else:
            print(f'\t{i + 1 - counter})', data_choice[i])
    answer = input()
    while not answer.isdigit() or not 0 < int(answer) <= len(data_choice):
        answer = input('Неправильный формат данных! Введите снова: \n')
    answer = int(answer)
    if answer <= len(list_of_text[1]):
        item = 1
        k = 0
    elif answer >= len(list_of_text[1]) + len(list_of_text[2]) + 1:
        item = 3
        k = len(list_of_text[1]) + len(list_of_text[2])
    else:
        item = 2
        k = len(list_of_text[1])
    reading(answer - k - 1, item)

def choices(func):
    '''
    Вызывает функцию
    :param func: некая функция
    :return: func()
    '''
    return func()


def not_eyes_choise():
    '''
    Случайный выбор текста, если в prepare_to_read выбрали 2
    :return:
    '''
    item = random.randint(1, len(list_of_text))
    rand = random.randint(0, len(list_of_text[item]) - 1)
    reading(rand, item)


def proof():
    '''
    Проверка готовности пользователя к чтению текста + инструкция остановки таймера
    :return: None
    '''
    print('Вам будет предоставлен тект, который вы должны прочитать. При ответе на вопрос сохраняйте падеж.\n'
          '\tПо прочтению подтвердите ваше окончание одной команд: "stop", "s", "с", "стоп"')
    answer = input('Готовы?\n').lower()
    while answer not in p_n:
        answer = input('Ответьте понятнее: \n').lower()
    if answer in positive:
        print('Поехали!')
        print('-' * 15)
        return
    elif answer in negative:
        print('Эм... Ну ладно... До свидания!')
        exit()


def answer_and_ask(time:float, limit:int, sp_ask_answer_1:list, sp_ask_answer_2:list):
    '''
    Ответы на 2 вопроса, если они верны, то вывод результата после прочтения
    :param time: время таймера
    :param limit: средний результат чтения
    :param sp_ask_answer_1: 1-ый вопрос и ответ
    :param sp_ask_answer_2: 2-ой вопрос и ответ
    :return: prepare_to_read(), если готов к дальнейшему чтению
    '''
    print(f'Ваш результат {time}')
    print('==' * 10)
    answer_1 = input(sp_ask_answer_1[0]).lower()
    answer_2 = input(sp_ask_answer_2[0]).lower()
    if answer_1 in sp_ask_answer_1[1:] and answer_2 in sp_ask_answer_2[1:]:
        if time <= limit:
            print('Моолодец! Это отличный результат')
        elif time <= limit * 1.2:
            print('Это приемлемый результат')
        else:
            print('Это довольно посредственный результат')
    else:
        print('Вы на что-то неправильно ответили!')
    print('==' * 10)
    answer = input('Продолжить чтениe?\n').lower()
    while answer not in p_n:
        answer = input('Я не понимаю(: \n').lower()
    print('~~' * 15)
    if answer in positive:
        prepare_to_read()
    elif answer in negative:
        print('Прощайте!')
        exit()


def timer():
    '''
    Таймер
    :return: time - время чтения
    '''
    time_start = 0
    time_start = tm()
    answer = input().lower()
    while not answer in ['stop', 's', 'с', 'стоп']:
        print('Неизвестная команда!')
        answer = input()
    else:
        time = round(tm() - time_start, 2)
        time_start = 0
    return time


def reading(number:int, item:int):
    '''
    Печать текста + вызов proof() (проверки чтения)
    :param number: номер текста в файле
    :param item: номер файла
    :return: answer_and_ask(time, limit, sp_ask_answer_1.split('|'), sp_ask_answer_2.split('|'))
    '''
    start_line, stop_line, aa, limit = list_of_text[item][number]
    proof()
    file = codecs.open(list_of_files[item - 1], 'r', 'utf_8_sig')
    for i, line in enumerate(file):
        if i < start_line:
            continue
        if i == aa - 1:
            sp_ask_answer = line.strip().split('&')
            break
        if i == stop_line:
            break
        line = line.replace("\n", "")
        if i >= start_line:
            print(line)
    file.close()
    sp_ask_answer_1, sp_ask_answer_2 = random.sample(sp_ask_answer, k=2)
    time = timer()
    answer_and_ask(time, limit, sp_ask_answer_1.split('|'), sp_ask_answer_2.split('|'))


if cheching_for_start(): #Если все файлы присутствуют
    positive = ['y', 'yes', 'lets do it', 'да', 'давай', 'приступай', 'д']
    negative = ['n', 'no', 'not do it', 'нет', 'отказываюсь', 'я не хочу', 'н']
    p_n = positive + negative
    list_of_offers = ['1) Выбрать текст самостоятельно.', '2) Выбор текста в слепую.', '3) Закрыть приложение.']
    list_of_func = [choice_of_text, not_eyes_choise]
    list_of_files = ['texts_for_reading/texts_light_level.txt',
                     'texts_for_reading/texts_medium_level.txt',
                     'texts_for_reading/texts_hard_level.txt']
    list_of_text = {1 : [(0, 9, 10, 51), (11, 23, 24, 56), (25, 43, 44, 91), (46, 67, 68, 91), (70, 93, 94, 121)], # Журавли / Синицы / Миф / Вр /Ноб
                    2 : [(0, 15, 16, 55)], # Кусака
                    3 : [(0, 22, 23, 101), (25, 42, 43, 55), (45, 62, 63, 65), (65, 80, 81, 65)]} # Глазки / Мышцы / См / Нейроны
    greeting()
else:
    print("Не хватает важных данных!")
